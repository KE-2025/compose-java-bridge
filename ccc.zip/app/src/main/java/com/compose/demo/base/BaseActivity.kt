package com.compose.demo.base

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.compose.demo.layout.ILayout
import com.compose.demo.layout.LayoutManager

abstract class BaseActivity : ComponentActivity() {
    
    private var contentLayout: ILayout? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
    }
    
    protected fun setContentView(layout: ILayout) {
        contentLayout = layout
        LayoutManager.register(layout)
        setContent {
            LayoutManager.getContent().invoke()
        }
    }
}
