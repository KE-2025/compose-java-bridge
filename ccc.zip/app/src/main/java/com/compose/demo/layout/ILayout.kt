package com.compose.demo.layout

import androidx.compose.runtime.Composable

interface ILayout {
    @Composable
    fun Content()
}
