package com.compose.demo.layout

import androidx.compose.runtime.Composable

object LayoutManager {
    
    private var currentLayout: ILayout? = null
    
    @JvmStatic
    fun register(layout: ILayout) {
        currentLayout = layout
    }
    
    @Composable
    fun getContent(): @Composable () -> Unit = {
        currentLayout?.Content()
    }
    
    @JvmStatic
    fun getLayout(): ILayout? = currentLayout
}