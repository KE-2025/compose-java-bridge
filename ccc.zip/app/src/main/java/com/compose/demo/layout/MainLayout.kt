package com.compose.demo.layout

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.compose.demo.theme.ComposeEmptyActivityTheme

class MainLayout : ILayout {

    @JvmField
    var title = mutableStateOf("Compose 演示")  
    @JvmField
    var buttontext = mutableStateOf("点击体验")  
    @JvmField
    var subtitle = mutableStateOf("Java + Compose 完美协作")
    
    interface OnButtonClickListener {
        fun onButtonClick()
    }
    
    var buttonClickListener: OnButtonClickListener? = null
    
    @Composable
    override fun Content() {
        ComposeEmptyActivityTheme {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = title.value,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = subtitle.value,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(
                        onClick = {
                            buttonClickListener?.onButtonClick()
                        }
                    ) {
                        Text(text = buttontext.value, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}