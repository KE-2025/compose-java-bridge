package com.compose.demo;

import android.os.Bundle;
import android.widget.Toast;
import com.compose.demo.base.BaseActivity;
import com.compose.demo.layout.MainLayout;

public class MainActivity extends BaseActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainLayout mainLayout = new MainLayout();
        setContentView(mainLayout);
        mainLayout.title.setValue("欢迎使用 Compose");
        mainLayout.subtitle.setValue("Android 现代 UI 工具包");
        mainLayout.setButtonClickListener(() -> {
            mainLayout.title.setValue("体验成功！");
            mainLayout.buttontext.setValue("已点击");
            mainLayout.subtitle.setValue("Java 和 Compose 无缝协作");
            Toast.makeText(MainActivity.this, "欢迎使用 Compose！", Toast.LENGTH_SHORT).show();
        });
    }
}